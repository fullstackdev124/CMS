#============================================================= -*-Perl-*-
#
# OSIPsk::HandleDialog.pm
#
# DESCRIPTION
#
#   This module provide cli prompt arguments for OpenSIPs Swiss Knife
#   
# AUTHOR
#   Danilo Santoro <dsantoro@tecnonetspa.it>
#
# COPYRIGHT
#   Copyright (C) 2013 Danilo 'Parantido' Santoro @ Tecnonet S.p.A.
#
# REVISION
#   $Id: OSIPsk::HandleDialog.pm 1 2013-04-19 17:49:00 CET
#
#=====================================================================================

package OSIPsk::HandleDialog;

use 5.008008;
use warnings;
use Crypt::CBC;
use Time::HiRes qw(usleep);
use Net::Domain qw(hostfqdn);

require Exporter;

# Includo le librerie locali
use lib qw(.);
use lib qw(..);
use OSIPsk::HandleFIFO;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration use OSIPsk::HandleDialog ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS	= ( 'all' => [ qw( ) ] );

our @EXPORT_OK		= ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT		= qw( );

our $VERSION		= '1.00';

####################################################
#                                                  #
#                 MODULE VARIABLES                 #
#                                                  #
####################################################
 #==================================================#

my $isInitialized	= undef;
my $exact_match		= 0;
my $hostfqdn		= hostfqdn();
my $osipskFIFO		= OSIPsk::HandleFIFO;

####################################################
#                                                  #
#                 PUBLIC METHODS                   #
#                                                  #
####################################################
 #==================================================#

sub new {
    my $pkg = shift;
    my $this = {};

    # Importa il nome di classe
    bless ($this, $pkg);

    # Ritorna il puntatore a classe
    return $this;
}

sub init() {

	my $this	= shift;
	my $osipskFIFO	= shift;
	my $pass_match	= shift;

	if($osipskFIFO) { $isInitialized = 1; }
	if($pass_match) { $exact_match = 1; }

	return($isInitialized);

}

sub kill_stucked_dialog {

	# Exit on not initialized
	if(not $isInitialized) { return undef; }

	# Looking For Dialog
	my %dia = &search_stucked_dialogs();

	# Check For Correct Returns
	if(%dia) {
		# Cycle'em
		my $found = 0;
		while(my ($key, $value) = each(%dia)) {
			if(defined($value)) {
				# Get Hash Dialog
				my %hsh = %$value;

				# Go ahead on malformed dialog
				next if(not $hsh{"dialog"} =~ /hash=(.*):(.*)/);

				# Kill Callee Leg - Send to Failure Route
				my $command = "dlg_end_dlg " .$1. " " .$2;
				$osipskFIFO->fifo_cmd($command);

				# Set as found
				$found = 1;
			}
		}

		# Dialog Not Found
		if($found) { return(0); } else { return(1); }
	} else {
		return(0);
	}
}

sub kill_cleg {

	# Exit on not initialized
	if(not $isInitialized) { return undef; }
	
	my $this = shift;
	my $hash = shift;

	if($hash =~ /hash=(.*):(.*)/) {
		my $command = "dlg_end_dlg " .$1. " " .$2;
		$osipskFIFO->fifo_cmd($command);
		return(1);
	} else {
		printf("[ WARNING ] Insert dialog-id in format 'hash=<id>:<entry>' as reported by dlg_list command\n");
		return(0);
	}

}

sub kill_dialog_early_state {
	# Exit on not initialized
	if(not $isInitialized) { return undef; }
	
	my $this = shift;
	my $callid = shift;
	my $recall = shift;
	my $state = 0;
	# W-A: patton doesn't uses callid <string@host> formatted
	# if($callid =~ /(.*)@(.*)/) {
	if($callid =~ /(.*)/) {
		my $command = "dlg_list $callid";
		my @ret = $osipskFIFO->fifo_cmd($command);
		my $commandkill = "";
		# Search For dialog
		foreach(@ret) {

			# Sanitize Line
			my $line = $_;
			$line =~ s/\n+//g;
			$line =~ s/\*/\\*/g;
			$line =~ s/[\t ]*//g;


			# Split Line Key/Value
			my @data = split('::', $line);
			
			# Skip if not valued
			next if(not $data[0]);

			if(length($data[0]) > 0) {
				if(($_ =~ /hash=(.*):(.*)/) || ($_ =~ /ID=(.*)/)) {
					 $commandkill = "dlg_end_dlg " .$1. " " .$2;
					 next;
				}
				# Check For Dialog State
				if($data[0] =~ /state/) {
					if($data[1] =~ /2/ && !($commandkill eq "")) {
						# Is an early state to check is in state 2.
						$osipskFIFO->fifo_cmd($commandkill);
						return(1);
					} else {
						# Not an early dialog ... skip
						return(0);
					}
				}
			}
		}
		return(0);
	} else {
		printf("[ WARNING ] Insert call-id in format '<id>@<host>' as reported by dlg_list command\n");
		return(0);
	}
}
	 
sub kill_callid {

	# Exit on not initialized
	if(not $isInitialized) { return undef; }
	
	my $this = shift;
	my $callid = shift;
	my $recall = shift;

	# W-A: patton doesn't uses callid <string@host> formatted
	# if($callid =~ /(.*)@(.*)/) {
	if($callid =~ /(.*)/) {
		my $command = "dlg_list $callid";
		my @ret = $osipskFIFO->fifo_cmd($command);

		# Return if not found
		if($#ret == 0 && $recall > 0) {
			return(0);
		} elsif($#ret == 0 && !$recall) {
			sleep(1);
			&kill_callid(undef, $callid, 1);

		} 
		foreach(@ret) {
			if($_ =~ /hash=(.*):(.*)/) {
				my $command = "dlg_end_dlg " .$1. " " .$2;
				$osipskFIFO->fifo_cmd($command);
				return(1);
			}
		}
	
		return(-1);
	} else {
		printf("[ WARNING ] Insert call-id in format '<id>@<host>' as reported by dlg_list command\n");
		return(0);
	}
}

sub check_gateway() {

	# Exit on not initialized
	if(not $isInitialized) { printf("0\n"); exit; }

	my $this = shift;
	my $gwid = shift;

	my $command = "dr_gw_status $gwid";
	my @ret = $osipskFIFO->fifo_cmd($command);

	foreach(@ret) {
		my $line = $_;
		$line =~ s/\n+//g;

		next if(length($line) le 0);

		if($line =~ /Enabled::\s*yes/ || $line =~ /State::\s*Active/) {
			return(1);
		}
	}

	# Return 0 on not found
	return(0);

}

sub check_pickup() {
	# Exit on not initialized
	if(not $isInitialized) { printf("0\n"); exit; }

	my $this  = shift;
	my $subid = shift;
	my $exact_match = shift;
	my $use_base_domain = shift;

	# Looking For Dialog
	my %dia = &search_pickeable_dialogs("to_uri", $subid, $exact_match, $use_base_domain);
}

sub encrypt_callid() {

	# Exit on not initialized
	if(not $isInitialized) { printf("0\n"); exit; }

	my $this	= shift;
	my $callid	= shift;
	my $osipsk_ckey	= shift;

	# Crypt Call-ID
  		my $crypto = Crypt::CBC->new(
		-key    => $osipsk_ckey,
		-cipher => Crypt::DES_EDE3
	);
	my $kcallid = $crypto->encrypt_hex($callid);

	if(length($kcallid)) {
		printf("1\n$kcallid\n");
	} else {
		printf("0\n");
	}

	return;
}

sub decrypt_callid() {

	# Exit on not initialized
	if(not $isInitialized) { printf("0\n"); exit; }

	my $this	= shift;
	my $kcallid	= shift;
	my $osipsk_ckey	= shift;

	# Crypt Call-ID
  		my $crypto = Crypt::CBC->new(
		-key    => $osipsk_ckey,
		-cipher => Crypt::DES_EDE3
	);
	my $callid = $crypto->decrypt_hex($kcallid);

	if(length($callid)) {
		printf("1\n$callid\n");
	} else {
		printf("0\n");
	}

	return;
}

sub extension_pickup() {

	# Exit on not initialized
	if(not $isInitialized) { printf("0\n"); exit; }

	my $this		= shift;
	my $srcid		= shift;
	my $subid		= shift;
	my $exact_match		= shift;
	my $use_base_domain	= shift;
	my $osipsk_ckey		= shift;

	# DEBUG
	#`echo "EXTENSION PICKUP: $srcid $subid $exact_match $use_base_domain $osipsk_ckey" > /tmp/pickup-debug.log`;

	# Looking For Dialog
	my %dia = &search_pickeable_dialogs("to_uri", $subid, $exact_match, $use_base_domain);

	# Found Checker
	my %hsh		= ();
	my $found	=  0;
	my $h_entry	= undef;
	my $h_id	= undef;
	my $callid	= undef;
	my $callercontact = undef;

	# Check For Correct Returns
	if(%dia) {
		# Retrieve Dialogs
		my $num_dialogs = scalar keys %dia;

		# DEBUG
		# `echo "Found Dialogs: $num_dialogs" >> /tmp/pickup-debug.log`;

		# Cycle'em
		while(my ($key, $value) = each(%dia)) {

			# DEBUG
			# `echo "Handle Key: $key" >> /tmp/pickup-debug.log`;

			if(defined($value)) {
				# Get Hash Dialog
				%hsh = %$value;

				# Go ahead if Multiple Dialog Returned
				# and we're inspecting external leg
				next if($num_dialogs > 1 && (not defined($hsh{"realcid"})));
				
				# Go ahead on malformed dialog
				next if(not $hsh{"dialog"} =~ /hash=(.*):(.*)/);

				# Update Dialog Entry/Id
				$h_entry = $1;
				$h_id    = $2;
				$callid  = $hsh{"callid"};
				$callercontact  = $hsh{"dlg_entity"};
				
				# DEBUG
				# `echo "HEntry: $h_entry HId: $h_id Callid: $callid" >> /tmp/pickup-debug.log`;

				# Get Killed Party
				my $kuser = undef;
				if($hsh{"to_uri"} =~ /sip:(.*)@.*/) {
					$kuser = $1;

					# DEBUG
					# `echo "Kill User: $kuser" >> /tmp/pickup-debug.log`;
				}
				
				# Set dialog as found
				if(not $found) {
					$found  = "1\n" .$hsh{"callid"}. "\n" .$kuser. "\n".$callercontact ."\n";

					# DEBUG
					# `echo "Not Found: $found" >> /tmp/pickup-debug.log`;
				} elsif(($hsh{"isexternal"}) || ($found && $hsh{"isexternal"})) {
					$found  = "1\n" .$hsh{"callid"}. "\n" .$kuser. "\n".$callercontact ."\n";

					# DEBUG
					# `echo "Found: $found" >> /tmp/pickup-debug.log`;
				}
			}
		}
	# DEBUG
	# } else {
	#	`echo "No dialogs found!" >> /tmp/pickup-debug.log`;
	}

	if($found) {
		# Kill Uneeded Callee Leg - Send to Failure Route
		# my $command = "dlg_end_dlg " .$h_entry. " " .$h_id;
		# my $command = "t_uac_cancel " .$hsh{"callid"}. " " .$hsh{"caller_cseq"};
		# $osipskFIFO->fifo_cmd($command);

		# Print Found Line
		printf("%s", $found);

		# Return true to main core
		return(1);
	} else {
		# Return nothing found
		printf("0\n");

		# Return false to main core
		return(0);
	}

}

sub group_pickup() {

	# Exit on not initialized
	if(not $isInitialized) { printf("0\n"); exit; }

	my $this  = shift;
	my $group = shift;
	my $range = shift;
	my $minimum = shift;
	my $exact_match = shift;
	my $use_base_domain = shift;

	# Randomize request time
	my $randtime = int(rand($range)) + $minimum;
	usleep($randtime);

	# Looking For Dialog
	my %dia = &search_pickeable_dialogs("to_uri", $group, $exact_match, $use_base_domain);

	# Found Checker
	my $found   = 0;
	my $h_entry = undef;
	my $h_id    = undef;

	# Check For Correct Returns
	if(%dia) {

		# Retrieve Dialogs
		my $num_dialogs = scalar keys %dia;
		
		# Cycle'em
		while(my ($key, $value) = each(%dia)) {
			if(defined($value)) {
				# Get Hash Dialog
				my %hsh = %$value;

				# Go ahead if Multiple Dialog Returned
				# and we're inspecting external leg
				next if($num_dialogs > 1 && (not defined($hsh{"realcid"})));
				
				# Go ahead on malformed dialog
				next if(not $hsh{"dialog"} =~ /hash=(.*):(.*)/);

				# Update Dialog Entry/Id
				$h_entry = $1;
				$h_id = $2;
				$callercontact  = $hsh{"caller_contact"};

				# Set dialog as found
				if(not $found) {
					$found  = "2\n" .$hsh{"callid"}. "\n" .$callercontact ."\n";
				} elsif(($hsh{"isexternal"}) || ($found && $hsh{"isexternal"})) {
					$found  = "2\n" .$hsh{"callid"}. "\n" .$callercontact ."\n";
				}
			}
		}
	}

	if($found) {
		# Kill Callee Leg - Send to Failure Route
		my $command = "dlg_end_dlg " .$h_entry. " " .$h_id;
		$osipskFIFO->fifo_cmd($command);

		# Print Found Line
		printf("%s", $found);

		# Return true to main core
		return(1);
	} else {
		# Return nothing found
		printf("0\n");

		# Return false to main core
		return(0);
	}

}

sub search_pickupper_dialogs() {

	my $this	= shift;
	my $key		= shift;
	my $domain	= shift;

	# Check if context Needed
	my $command	= "dlg_list_ctx";
	
	# DEBUG
	# `echo "Chiave: $key Dominio: $domain" >> /tmp/pickup-debug.log`;
		
	# Retrieve Output
	my @ret		= $osipskFIFO->fifo_cmd($command);

	# Dialog Data Structure
	my %dialogs	= ();
	my %dialog	= ();

	if(not $#ret) { return %dialogs; }

	# Dialog Status Counter 
	my $count = 0;
	my $found = 0;

	# Search For dialog
	foreach(@ret) {

		# Sanitize Line
		my $line = $_;
		$line =~ s/\n+//g;
		$line =~ s/\*/\\*/g;
		$line =~ s/[\t ]*//g;

		# Split Line Key/Value
		my @data = split('::', $line);

		# Skip if not valued
		next if(not $data[0]);

		# If found push dialog in the stack and
		# purge counters
		if($data[0] =~ /^dialog$/ && $count gt 0) {
			if($found) {
				my %tmp = %dialog;
				$dialogs{$dialog{'dialog'}} = \%tmp;
			}

			# Purging Counter
			$found = 0;

			# Purging Dialog Structure
			%dialog = ();
		}
		
		# Populating Hash Data
		if(length($data[0]) > 0) {

			# DEBUG
			# `echo "Data Check: $data[0]" >> /tmp/pickup-debug.log`;

			# Looking for Matching Key/Value
			if($data[0] =~ /$key/) {

				# DEBUG
				# `echo "IF $data[0] =~ /$key/" >> /tmp/pickup-debug.log`;

				# Get Base FQDN Host name
				my $basehostfqdncontact   = &get_domainfromct($data[1]);

				# DEBUG
				# `echo "Base Host FQDN Contact: $basehostfqdncontact from $data[1]" >> /tmp/pickup-debug.log`;
				# `echo "IF $data[1] =~ /sip:(.*)\@$hostfqdn.*/ || $data[1] =~ /$basehostfqdncontact/" >> /tmp/pickup-debug.log`;

				# Get Dialogs With Matching local FQDN/BaseFQDN
				if($data[1] =~ /sip:(.*)\@$hostfqdn.*/ || $data[1] =~ /$basehostfqdncontact/) {

					# DEBUG
					# `echo -n "IF $domain ... " >> /tmp/pickup-debug.log`;

					# If requested retrive dialog base domain
					if($domain) { 
						# DEBUG
						# `echo "OK" >> /tmp/pickup-debug.log`;
						$data[1] = &get_domainfromct($data[1]);
					# DEBUG
					# } else {
					#	`echo "NOT OK" >> /tmp/pickup-debug.log`;
					}
				}

			} elsif($data[0] =~ /value/ && $data[1] =~ /pckby=(.*)/) {

				# DEBUG
				# `echo "IF $data[0] =~ /value/ && $data[1] =~ /pckby=(.*)/" >> /tmp/pickup-debug.log`;

				# Write Info
				$dialog{"pckby"} = $1;

				if($1 =~ /$key/) {
					# DEBUG
					# `echo "$1 =~ /$key/" >> /tmp/pickup-debug.log`;
					# Pickupper Found
					printf("1\n");
					return(1);
				}

			}

			$dialog{$data[0]} = $data[1];
		}

		# Count++
		$count++;
	}

	# No Pickupper Found
	printf("0\n");
	return(0);

}

####################################################
#                                                  #
#                 PRIVATE METHODS                  #
#                                                  #
####################################################
 #==================================================#

sub get_domainfromct() {

	# Get Contact List
	my $contact = $_[0];

	# Strip Domain Part
	my @ct  = split('@', $contact);
	# Split Domain Levels
	my @lvl = split('\.', $ct[1]);
	@lvl = reverse(@lvl);

	# Get Main Domain
	my $dmn = undef;
	if(@lvl == 1) {
		$dmn = $lvl[0];
	} else 
	{
		if(@lvl == 4)
		{
			# if the domain is an ip (dialog for cisco phone) use it as domain
			$dmn = $lvl[3]. "." .$lvl[2]. "." .$lvl[1]. "." .$lvl[0];
		} else {
			$dmn = $lvl[1]. "." .$lvl[0];
		}
	}
	# Rebuild Contact
	my $value = $ct[0]. "@.*" .$dmn;

	# Rebuild Contact if Exact Match
	if($exact_match) {
		$value = $ct[0]. "@" .$dmn;
	}

	# Return
	return($value);

}

sub search_stucked_dialogs() {

	# Check if context Needed
	my $command	= "dlg_list";

	# Dialog Status Counter 
	my $count = 0;
	my $found = 0;
	my $state = 0;

	# Retrieve Output
	my @ret   = $osipskFIFO->fifo_cmd($command);

	# Dialog Data Structure
	my %dialogs	= ();
	my %dialog	= ();

	# No dialogs present
	if(not $#ret) { return %dialogs; }

	# Search For dialog
	foreach(@ret) {

		# Sanitize Line
		my $line = $_;
		$line =~ s/\n+//g;
		$line =~ s/\*/\\*/g;
		$line =~ s/[\t ]*//g;

		# Split Line Key/Value
		my @data = split('::', $line);

		# If found push dialog in the stack and purge
		# counters
		if($data[0] =~ /^dialog$/) {
			if($found && $state) {
				my %tmp = %dialog;
				$dialogs{$dialog{'dialog'}} = \%tmp;
			}

			# Purging Counter
			$found = $state = 0;

			# Purging Dialog Structure
			%dialog = ();

			# Update Hash
			if($data[1] =~ /hash=(.*):(.*)/) {
				$dialog{'dialog'} = "hash=$1:$2";
			}
		}
		
		# Populating Hash Data
		if(length($data[0]) > 0) {
			# Check For Stucked Dialog State
			if($data[0] =~ /state/) {
				if($data[1] =~ /3/) {
					# Is an early state
					$state = 1;
					$found = 1;
				} else {
					# Not a stucked dialog ... skip
					next;
				}
			}
		}
	}

	# Push last dialog if found
	if($found && $state) {
		my %tmp = %dialog;
		$dialogs{$dialog{'dialog'}} = \%tmp;
	}

	# Return Hash
	if(scalar keys %dialogs) { return(%dialogs); } else { return; }

}

sub search_pickeable_dialogs() {

	my $key		= $_[0];
	my $group	= $_[1];
	my $exact	= $_[2];
	my $domain	= $_[3];

	# Check if context Needed
	my $command	= "dlg_list_ctx";

	# Slit Group to Contacts
	my @contacts	= split(',', $group);

	# Retrieve Output
	my @ret		= $osipskFIFO->fifo_cmd($command);

	# Dialog Data Structure
	my %dialogs	= ();
	my %dialog	= ();

	if(not $#ret) { return %dialogs; }

	# Dialog Status Counter 
	my $count = 0;
	my $found = 0;
	my $state = 0;

	# Search For dialog
	foreach(@ret) {

		# Sanitize Line
		my $line = $_;

		$line =~ s/\n+//g;
		$line =~ s/\*/\\*/g;
		$line =~ s/\t*//g;
		$line =~ s/::[\t ]*/::/g;
		$line =~ s/[\t ]*=[\t ]*/=/g;

		# Split Line Key/Value
		my @data = split('::', $line);

		# Skip if not valued
		next if(not $data[0]);

		# If found push dialog in the stack and
		# purge counters
		if($data[0] =~ /^dialog$/ && $count gt 0) {

			# DEBUG
			# `echo "1) IF $data[0] =~ /^dialog/ && $count gt 0 ($found && $state)\n" >> /tmp/pickup-debug.log`;

			if($found && $state) {
		
				# DEBUG
				# `echo "2) Line: $line\n" >> /tmp/pickup-debug.log`;

				my %tmp = %dialog;
				$dialogs{$dialog{'dialog'}} = \%tmp;
			}

			# Purging Counter
			$found = $state = 0;

			# Purging Dialog Structure
			%dialog = ();
		}
		
		# Populating Hash Data
		if(length($data[0]) > 0) {
			# Check For Early Dialog State
			if($data[0] =~ /state/) {
				if($data[1] =~ /2/) {
					# Is an early state
					$state = 1;
					# DEBUG
					# `echo "3) Dialog in early state" >> /tmp/pickup-debug.log`;
				} else {
					# Not an early dialog ... skip
					next;
				}
			}

			# Looking for Matching Key/Value
			if($state && $data[0] =~ /$key/) {
				# Get Base FQDN Host name
				my $basehostfqdncontact   = &get_domainfromct($data[1]);

				# DEBUG
				# `echo "4) IF $state && $data[0] =\~ \/$key\/" >> /tmp/pickup-debug.log`;

				# Get Dialogs With Matching local FQDN/BaseFQDN
				if($data[1] =~ /sip:(.*)\@$hostfqdn.*/ || $data[1] =~ /$basehostfqdncontact/) {

					# DEBUG
					# `echo "5) IF $data[1] =~ /sip:(.*)\@$hostfqdn.*/ || $data[1] =~ /$basehostfqdncontact/" >> /tmp/pickup-debug.log`;

					# If requested retrive dialog base domain
					if($domain) { 
						# DEBUG
						# `echo "6) OK" >> /tmp/pickup-debug.log`;
						$data[1] = &get_domainfromct($data[1]);
					}
				}

			} elsif($state && $data[0] =~ /viaheader/) {

				# DEBUG
				# `echo "7) $state && $data[0] =~ /viaheader/" >> /tmp/pickup-debug.log`;

				# Write Info
				$dialog{"via"} = $data[1];

			} elsif($state && $data[0] =~ /bydispatchers/) {

				# DEBUG
				# `echo "7) $state && $data[0] =~ /bydispatchers/" >> /tmp/pickup-debug.log`;

				# Write Info
				$dialog{"isexternal"} = $data1;

			} elsif($state && $data[0] =~ /(internalcid|sargs)/) {

				# DEBUG
				# `echo "7) $state && $data[0] =~ /(internalcid|sargs)/" >> /tmp/pickup-debug.log`;

				# Write Info
				$dialog{"realcid"} = $data[1];

				foreach(@contacts) {
					# DEBUG
					# `echo "XXX) $_ =~ /sip:.*$dialog{"realcid"}\@.*/" >> /tmp/pickup-debug.log`;
					if($_ =~ /.*$dialog{"realcid"}.*/) {
						# DEBUG
						# `echo "XXX) FOUND!" >> /tmp/pickup-debug.log`;
						$found = 1;
					# DEBUG
					# } else {
					#	`echo "XXX) NOT FOUND!" >> /tmp/pickup-debug.log`;
					}
				}
			}

			$dialog{$data[0]} = $data[1];
		}

		# Count++
		$count++;
	}

	# Push last dialog if found
	if($found && $state) {
		# DEBUG
		# `echo "8) DIALOG FOUND! $found && $state" >> /tmp/pickup-debug.log`;
		my %tmp = %dialog;
		$dialogs{$dialog{'dialog'}} = \%tmp;
	# DEBUG
	# } else {
	#	`echo "8) DIALOG NOT FOUND! $found && $state" >> /tmp/pickup-debug.log`;
	}

	# Return Hash
	if(scalar keys %dialogs) { return(%dialogs); } else { return; }
}

1;

__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

OSIPsk::HandleDialog - Perl extension for blah blah blah

=head1 SYNOPSIS

  use OSIPsk::HandleDialog;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for OSIPsk::HandleDialog, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

parantido, E<lt>parantido@E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by root

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.8 or,
at your option, any later version of Perl 5 you may have available.


=cut
