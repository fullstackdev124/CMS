#============================================================= -*-Perl-*-
#
# OSIPsk::HandlePckt.pm
#
# DESCRIPTION
#
#   This module handle raw level network packet sending
#   
# AUTHOR
#   Danilo Santoro <dsantoro@tecnonetspa.it>
#
# COPYRIGHT
#   Copyright (C) 2013 Danilo 'Parantido' Santoro @ Tecnonet S.p.A.
#
# REVISION
#   $Id: OSIPsk::HandlePckt.pm 1 2013-04-19 17:49:00 CET
#
#=====================================================================================

package OSIPsk::HandlePckt;

use 5.008008;
use warnings;
use IO::Socket;

require Exporter;

# Includo le librerie locali
use lib qw(.);
use lib qw(..);

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration use OSIPsk::HandlePckt ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw( );

our $VERSION = '1.00';

####################################################
#                                                  #
#                 MODULE VARIABLES                 #
#                                                  #
####################################################
 #==================================================#

my $isInitialized	=  undef;
use constant MAXBYTES	=> scalar 80;

####################################################
#                                                  #
#                 PUBLIC METHODS                   #
#                                                  #
####################################################
 #==================================================#

sub new {

	my $pkg = shift;
	my $this = {};
	
	# Importa il nome di classe
	bless ($this, $pkg);
	
	# Ritorna il puntatore a classe
	return $this;

}

sub init() {

	my $this = shift;

	# Fake Init ... not needed at moment
	if($this) {
		$isInitialized = 1;
	}

	return($isInitialized);

}

sub isInitialized() {

	my $this = shift;
	return($isInitialized);

}

sub oneshoot_send_msg() {

	my $this	= shift;
	my $peeraddr	= shift;
	my $peerport	= shift;
	my $proto	= shift;
	my $payload	= shift;

	# Stop if not initialized
	if(not $isInitialized) { return undef; }

	my $sock = IO::Socket::INET->new(
		Proto    => $proto,
		PeerPort => $peerport,
		PeerAddr => $peeraddr,
	) or return(-1);

	# Sending Message to server
	$sock->send($payload) or return(-1);
	
	# Harm for server reply timeout
	# -- NOT REALLY NEEDED
	#eval {
	#	local $SIG{ALRM} = sub { return(-2); };
	#	alarm 5;
	#	$sock->recv(my $recvd, MAXBYTES);
	#	alarm 0;
	#	return($recvd);
	#}

}

####################################################
#                                                  #
#                 PRIVATE METHODS                  #
#                                                  #
####################################################
 #==================================================#


1;

__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

OSIPsk::HandlePckt - Perl extension for blah blah blah

=head1 SYNOPSIS

  use OSIPsk::HandlePckt;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for OSIPsk::HandlePckt, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

parantido, E<lt>parantido@E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2013 by parantido

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.8 or,
at your option, any later version of Perl 5 you may have available.

=cut
