#============================================================= -*-Perl-*-
#
# OSIPsk::HandleSIP.pm
#
# DESCRIPTION
#
#   This module provide cli prompt arguments for OpenSIPs Swiss Knife
#   
# AUTHOR
#   Danilo Santoro <dsantoro@tecnonetspa.it>
#
# COPYRIGHT
#   Copyright (C) 2013 Danilo 'Parantido' Santoro @ Tecnonet S.p.A.
#
# REVISION
#   $Id: OSIPsk::HandleSIP.pm 1 2013-04-19 17:49:00 CET
#
#=====================================================================================

package OSIPsk::HandleSIP;

use 5.008008;
use warnings;

require Exporter;

# Includo le librerie locali
use lib qw(.);
use lib qw(..);
use OSIPsk::HandleFIFO;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration use OSIPsk::HandleSIP ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS	= ( 'all' => [ qw( ) ] );

our @EXPORT_OK		= ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT		= qw( );

our $VERSION		= '1.00';

no warnings 'all';

####################################################
#                                                  #
#                 MODULE VARIABLES                 #
#                                                  #
####################################################
 #==================================================#

my %globalhash		= ();
my $isInitialized	= undef;
my $osipskFIFO		= OSIPsk::HandleFIFO;

####################################################
#                                                  #
#                 PUBLIC METHODS                   #
#                                                  #
####################################################
 #==================================================#

sub new {
	my $pkg = shift;
	my $this = {};
	
	# Importa il nome di classe
	bless ($this, $pkg);
	
	# Ritorna il puntatore a classe
	return $this;
}

sub init() {

	my $this	= shift;
	my $osipskFIFO	= shift;

	if($osipskFIFO) { $isInitialized = 1; }

	return($isInitialized);

}

sub blf_notifier() {

	if(not $isInitialized) { return(0); }

	my $this    = shift;
	my $type    = shift;
	my $watcher = shift;
	my $target  = shift;
	my $domain  = shift;
	my $state   = shift;
	my $proxy   = shift;

	# Notify all watchers about a state
	if($type =~ /^notify(all)*$/) {

		# Retrieve all local subscriptions
		my %subscribes = &get_subscriptions();

		# Check For Correct Returns
		if(not %subscribes || not (scalar keys %subscribes)) { return(0); }
	
		# Purge Target Line
		$target =~ s/\s+//g;
	
		# Split Target (if many contacts passed)
		my @targets = split(/,/, $target);
		my $num_trg = $#targets + 1;

		# Include Raw Packet lib
		use OSIPsk::HandlePckt;

		# use Data::Dumper;

		# Find watchers to notify
		$notified = 0;
		while(my ($key, $value) = each(%subscribes)) {
			# Get Temporary Hash
			%globalhash = %$value;

			# print Data::Dumper->Dump([\%globalhash], ["Global:"]);

			if($num_trg > 1) {
				foreach(@targets) {
					# Build Notify Contact
					my $contact = "sip:" .$_. "@" .$domain;
					$notified = &build_notify($watcher, $state, $proxy, $domain) if($contact eq $globalhash{'pres_uri'});
				}
			} else {
				# Build Notify Contact
				my $contact = "sip:" .$target. "@" .$domain;
				$notified = &build_notify($watcher, $state, $proxy, $domain) if($contact eq $globalhash{'pres_uri'});
			}

			# Purge Temporary Hash
			%globalhash = ();
		}

		# Almost a notify is sent
		return(1) if($notified);
	}

	# Return 0 Otherwise
	return(0);

}

sub send_pickup_redirect() {

	my $this	= shift;
	my $proto	= shift;
	my $ip		= shift;
	my $port	= shift;
	my $via		= shift;
	my $from	= shift;
	my $to		= shift;
	my $contact	= shift;
	my $callid	= shift;
	my $kcallid	= shift;
	my $cseq	= shift;
	my $parkme	= shift;

	# Build Message
	my $message =
		"SIP/2.0 302 Moved Temporarily\r\n" .
		"Via: $via\r\n" .
		"From: $from\r\n" .
		"To: $to\r\n" .
		"Call-ID: $callid\r\n" .
		"CSeq: $cseq INVITE\r\n" .
		"Contact: \"Chiamata Prelevata\" <$contact>\r\n" .
		"Diversion: sip:pickup\@monkeyoice.org?Parkme=$parkme;Key=$kcallid\r\n" .
		"Content-Length: 0\r\n" .
		"\r\n";

	# Sending Raw Packet
	my $pckt 	= OSIPsk::HandlePckt;
	if($pckt->init()) {
		my $ret = $pckt->oneshoot_send_msg($ip, $port, $proto, $message);
		return($ret);
	} else {
		return(0);
	}

}

sub send_bye() {
	my $this	= shift;
	my $peeraddr	= shift;
	my $peerport	= shift;
	my $proto	= shift;
	my $from	= shift;
	my $to		= shift;
	my $payload	= shift;

	$proto = "udp" if(length($proto) < 3);
	`echo "Passed: $peeraddr $peerport $proto $from $to $payload" > /tmp/debug.log`;

	# Stop if not initialized
	if(not $isInitialized) { return undef; }

	# Split payload by line
	my @lines = split /\n/, $payload;

	$payload = "";
	my $ua_addr = undef;
	my $ua_port = undef;
	foreach my $line (@lines) {
		#next if($line =~ /^Via.*/);
		next if($line =~ /^Route.*/);
		next if($line =~ /^X-Asterisk-.*/);

		# Strip carriage return from every line
		$line =~ s/\r[\n]*/\n/gm;
		chomp $line;

		if($line =~ /BYE sip:(.*)@(.*):(.*);user=phone;transport=(.*) SIP\/2.0/) {
			$ua_addr = $2;
			$ua_port = $3;
			$line = "BYE sip:$1\@$2:$3;user=phone;transport=$4 SIP/2.0"
		}

		if($line =~ /Via.*/) {
			$line = "Via: SIP/2.0/UDP $peeraddr:5066;branch=z9hG4bK123456.0987";
		}

		$line = "From: $to" if($line =~ /From:(.*)/);
		$line = "To: $from" if($line =~ /To:(.*)/);
		$line = "User-Agent: MonkeYFixer v1.0" if($line =~ /User-Agent:(.*)/);

		if($line =~ /CSeq:\s+(.*)\s+BYE/) {
			my $cseqnum = ($1 + 1);
			$line = "CSeq: $cseqnum BYE";
		}

		# Reattach carriage return after line fix
		$payload .= $line."\r\n";
	}

	`echo "Sending to $peeraddr:$peerport modified payload\n$payload\n" >> /tmp/debug.log`;

# Directly Sending to Ua
	my $sock = IO::Socket::INET->new(
		LocalAddr => $peeraddr,
		LocalPort => 5066,
		Proto    => $proto,
		PeerAddr => $ua_addr,
		PeerPort => $ua_port
# Handling through SIP Proxy
#	my $sock = IO::Socket::INET->new(
#		LocalAddr => $peeraddr,
#		LocalPort => 5066,
#		Proto    => $proto,
#		PeerAddr => $peeraddr,
#		PeerPort => $peerport
	) or do {
		`echo "Error establishing socket: $@\n" >> /tmp/debug.log`;
		return (-1);
	};

	`echo "Sent:\n$payload\nto $peeraddr:$peerport\n" >> /tmp/debug.log`;

	# Sending Message to server
	$sock->send($payload) or return(-1);
}

sub send_cancel() {

	my $this	= shift;
	my $proto	= shift;
	my $ip		= shift;
	my $port	= shift;
	my $via		= shift;
	my $from	= shift;
	my $to		= shift;
	my $contact	= shift;
	my $callid	= shift;
	my $cseq	= shift;

	# Build Message
	my $message =
		"CANCEL $contact SIP/2.0\r\n" .
		"$via\r\n" .
		"From: $from\r\n" .
		"Call-ID: $callid\r\n" .
		"To: $to\r\n" .
		"CSeq: $cseq CANCEL\r\n" .
		"Max-Forwards: 70\r\n" .
		"User-Agent: MonkeYoiceGW\r\n" .
		"Content-Length: 0\r\n" .
		"\r\n";

	# Sending Raw Packet
	my $pckt 	= OSIPsk::HandlePckt;
	if($pckt->init()) {
		my $ret = $pckt->oneshoot_send_msg($ip, $port, $proto, $message);
		return($ret);
	} else {
		return(0);
	}

}

####################################################
#                                                  #
#                 PRIVATE METHODS                  #
#                                                  #
####################################################
 #==================================================#

sub get_subscriptions() {

	my $this = shift;

	# Fifo Command
	my $command = "subs_phtable_list";
	my @ret = $osipskFIFO->fifo_cmd($command);

	# Initialize data structure
	my %subscribes = ();
	my %subscribe  = ();

	# Return an empty hash
	if(not $#ret) { return %subscribes; }

	# Start Subscribe Search
	my $step = 0;

	foreach(@ret) {

		# Go ahead on empty line
		next if(not length($_) > 1);

		# Retrieve actual Line
		my $line = $_;

		# Purge Line
		$line =~ s/^\s+//g;
		$line =~ s/^\n+//g;

		if($line =~ /pres_uri:: (.*) event=(.*) expires=(.*) db_flag=(.*) version=(.*)/g) {
			$subscribe{'pres_uri'}		= $1;
			$subscribe{'event'}		= $2;
			$subscribe{'expires'}		= $3;
			$subscribe{'db_flag'}		= $4;
			$subscribe{'version'}		= $5;

			# 1st Step Completed
			$step++;
		} elsif ($line =~ /to_user:: (.*) to_domain=(.*) to_tag=(.*)/) {
			$subscribe{'to_user'}		= $1;
			$subscribe{'to_domain'}		= $2;
			$subscribe{'to_tag'}		= $3;

			# 2nd Step Completed
			$step++;
		} elsif ($line =~ /from_user:: (.*) from_domain=(.*) from_tag=(.*)/) {
			$subscribe{'from_user'}		= $1;
			$subscribe{'from_domain'}	= $2;
			$subscribe{'from_tag'}		= $3;

			# 3rd Step Completed
			$step++;
		} elsif ($line =~ /callid:: (.*) local_cseq=(.*) remote_cseq=(.*)/) {
			$subscribe{'callid'}		= $1;
			$subscribe{'local_cseq'}	= $2;
			$subscribe{'remote_cseq'}	= $3;

			# 4th Step Completed
			$step++;
		}

		# Subscribe Found
		if($step == 4) {
			# Push new Subscribe
			my %tmp = %subscribe;
			$subscribes{$subscribe{'callid'}. "," .$subscribe{'from_tag'}. "," .$subscribe{'to_tag'}} = \%tmp;

			# Reinit DataStructures
			$step = 0;
			%subscribe = ();
		}
	}


	# Return Collected Subscribes
	return %subscribes;

}

sub build_notify() {

	my $watcher	= shift;
	my $state	= shift;
	my $proxy	= shift;
	my $domain	= shift;

	# Return on no value
	return(-1) if(not keys(%globalhash));
	
	# Build Notify Message Payload
	use Digest::MD5 qw(md5_hex);
	my $rand	= md5_hex(rand());
	my $content	= "<?xml version=\"1.0\"?>\n".
			  "<dialog-info xmlns=\"urn:ietf:params:xml:ns:dialog-info\" version=\"" .$globalhash{'version'}. "\" state=\"partial\" entity=\"" .$globalhash{'to_user'}. "\@" .$globalhash{'to_domain'}. "\"><dialog id=\"" .$rand. "\@" .$proxy. "\" direction=\"recipient\"><state>" .$state. "</state></dialog-info>\r\n";
#	my $content	= "<?xml version=\"1.0\"?>\n".
#		 	  "<dialog-info xmlns=\"urn:ietf:params:xml:ns:dialog-info\" version=\"" .$globalhash{'version'}. "\" entity=\"" .$globalhash{'to_user'}. "\@" .$globalhash{'to_domain'}. "\" state=\"partial\"><dialog id=\"" .$globalhash{'callid'}. "\" call-id=\"" .$globalhash{'callid'}. "\" direction=\"initiator\"><state>" .$state. "</state><remote><identity>" .$globalhash{'to_user'}. "\@" .$globalhash{'to_domain'}. "</identity><target uri=\"" .$globalhash{'to_user'}. "\@" .$globalhash{'to_domain'}. "\"/></remote><local><identity>" .$globalhash{'from_user'}. "\@" .$globalhash{'from_domain'}. "</identity><target uri=\"" .$globalhash{'from_user'}. "\@" .$globalhash{'from_domain'}. "\"/></local></dialog></dialog-info>\r\n";
	my $content_len	= length($content);

	# Build Source and Destination Entity
	my $srcuri	= $globalhash{'to_user'}.   "\@" .$globalhash{'to_domain'};
	my $dsturi	= $globalhash{'from_user'}. "\@" .$globalhash{'from_domain'};


#	NOTIFY sip:2003@192.168.53.213:5060;transport=udp SIP/2.0
#	Via: SIP/2.0/UDP 192.168.53.201:5060;branch=z9hG4bK5c2.ae1d4177.0
#	To: <sip:2003@monkeyvoice.org>;tag=5d85477be7
#	From: <sip:2002@monkeyvoice.org>;tag=7fe99bb12ab5c5af6b9c5de70b174f6e-fae6
#	CSeq: 4 NOTIFY
#	Call-ID: 24ac4eb54f7ded44
#	Max-Forwards: 70
#	Content-Length: 480
#	User-Agent: MonkeYoiceGW (voip-primary)
#	Event: dialog
#	Contact: <sip:sa@monkeyvoice.org:5060>
#	Subscription-State: active;expires=3532
#	Content-Type: application/dialog-info+xml
#	
#	<?xml version="1.0"?>
#	<dialog-info xmlns="urn:ietf:params:xml:ns:dialog-info" version="3" entity="sip:2002@monkeyvoice.org" state="partial"><dialog id="4ecc4427d99fd040" call-id="4ecc4427d99fd040" direction="initiator"><state>terminated</state><remote><identity>sip:*100@monkeyvoice.org</identity><target uri="sip:*100@monkeyvoice.org"/></remote><local><identity>sip:02@monkeyvoice.org</identity><target uri="sip:2002@monkeyvoice.org"/></local></dialog></dialog-info>

	# Build Notify Message
	my $message	=
		"NOTIFY sip:" .$dsturi. " SIP/2.0\r\n".
		"Via: SIP/2.0/UDP " .$proxy. "\r\n".
		"To: <sip:" .$dsturi. ">;tag=" .$globalhash{'from_tag'}. "\r\n".
		"From: <sip:" .$srcuri. ">;tag=" .$globalhash{'to_tag'}. "\r\n".
		"CSeq: " .($globalhash{'local_cseq'} + 1). " NOTIFY\r\n".
		"Call-ID: " .$globalhash{'callid'}. "\r\n".
		"User-Agent: MonkeYoice Notifier\r\n".
		"Event: " .$globalhash{'event'}. "\r\n".
		"Subscription-State: active\r\n".
		"Contact: <sip:" .$proxy. ">\r\n".
		"Content-Type: application/dialog-info+xml\r\n".
		"Content-Length: " .$content_len. "\r\n".
		"\r\n".
		$content;

	# Sending Raw Packet
	my $pckt 	= OSIPsk::HandlePckt;
	if($pckt->init()) {
		my $ret = $pckt->oneshoot_send_msg($proxy, 5060, "udp", $message);
		return(1);
	} else {
		return(0);
	}

}

1;

__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

OSIPsk::HandleSIP - Perl extension for blah blah blah

=head1 SYNOPSIS

  use OSIPsk::HandleSIP;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for OSIPsk::HandleSIP, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

parantido, E<lt>parantido@E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by root

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.8 or,
at your option, any later version of Perl 5 you may have available.


=cut
