#============================================================= -*-Perl-*-
#
# OSIPsk::HandleFIFO.pm
#
# DESCRIPTION
#
#   This module OpenSIPs FIFO Communication
#   
# AUTHOR
#   Danilo Santoro <dsantoro@tecnonetspa.it>
#
# COPYRIGHT
#   Copyright (C) 2013 Danilo 'Parantido' Santoro @ Tecnonet S.p.A.
#
# REVISION
#   $Id: OSIPsk::HandleFIFO.pm 1 2013-04-19 17:49:00 CET
#
#=====================================================================================

package OSIPsk::HandleFIFO;

use 5.008008;
use warnings;
use POSIX;

require Exporter;

# Includo le librerie locali
use lib qw(.);
use lib qw(..);

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration use OSIPsk::HandleFIFO ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw( );

our $VERSION = '1.00';

####################################################
#                                                  #
#                 MODULE VARIABLES                 #
#                                                  #
####################################################
 #==================================================#

my $isInitialized	= undef;
my $osips_fifo_file	= undef;
my $fifo_reply_file	= "mvoice_reply_" . $$;
my $fifo_reply_path	= "/tmp/" . $fifo_reply_file;

####################################################
#                                                  #
#                 PUBLIC METHODS                   #
#                                                  #
####################################################
 #==================================================#

sub new {

	my $pkg = shift;
	my $this = {};
	
	# Importa il nome di classe
	bless ($this, $pkg);
	
	# Ritorna il puntatore a classe
	return $this;

}

sub init() {

	my $this = shift;
	my $chk_fifo = shift;

	# Check if Fifo Exists
	if(-e $chk_fifo) {
		$isInitialized = 1;
		$osips_fifo_file = $chk_fifo;
	}

	return($isInitialized);

}

sub isInitialized() {

	my $this = shift;
	return($isInitialized);

}

sub fifo_cmd() {

	# Stop if not initialized
	if(not $isInitialized) { return undef; }

	my $this	= shift;

	my $arg_list	= "";
	my @fifo_cmd	= undef;
	my $cmd_fifo	= undef;
	
	if ($_[0]) {	
		@fifo_cmd = split(" ", $_[0]);		
	}	
	
	if ($#fifo_cmd == 0){
		$cmd_fifo = ":" . $fifo_cmd[0] . ":" . $fifo_reply_file . "\n";
	} elsif ($#fifo_cmd  gt 0){
		for (my $i = 1; $i < $#fifo_cmd +1; $i++) {
			$arg_list = join("",$arg_list,$fifo_cmd[$i],"\n");
		}

		$cmd_fifo = ":" . $fifo_cmd[0] . ":" . $fifo_reply_file . "\n" . $arg_list;
	}

	$cmd_fifo = join("", $cmd_fifo, "\n");
	return(&write_read_fifo($this, $cmd_fifo));

}

sub direct_command() {

	my $this = shift;
	my $cmd_fifo = shift;

	# Stop if not initialized
	if(not $isInitialized) { return undef; }

	# Send Command to Fifo
	my @ret = &fifo_cmd($this, $cmd_fifo);

	# Handle OpenSIPs Result
	foreach(@ret) {
		my $line = $_;
		$line =~ s/\n+//g;
		next if(length($line) le 0);
		printf("%s\n", $line);
	}

}

####################################################
#                                                  #
#                 PRIVATE METHODS                  #
#                                                  #
####################################################
 #==================================================#

sub write_read_fifo() {

	my $this = shift;
	my $cmd_fifo = shift;

	# Stop if not initialized
	if(not $isInitialized) { return undef; }

	# Check if Osips Fifo Exists
	if (not -e $osips_fifo_file) {
		print "OpenSIPs's FIFO " .$osips_fifo_file. " does not exists!\n";
		printf("0\n");;	
		exit;
	}

	# Check if Osips Fifo is Writeable
	if (not -w $osips_fifo_file) {
		print "OpenSIPs's FIFO " .$osips_fifo_file. " not writeable!\n" . 
		printf("0\n");;	
		exit;
	}

	# Create Osips Fifo Reply
	unless (-p $fifo_reply_path) {
		unlink $fifo_reply_path;
		mkfifo ($fifo_reply_path, 666) or die "mkfifo $fifo_reply_path failed: $!"; 
	}

	# Check if Osips Fifo Reply Exists
	if (not -e $fifo_reply_path) {
		print "OpenSIPs's FIFO " .$fifo_reply_path. " not exists!\n" . 
		printf("0\n");;	
		exit;
	}
	
	# Set Fifo Writeable
	`chmod a+rw $fifo_reply_path`;

	# Push command to Osips Fifo
	open(ANS,">$osips_fifo_file") or die "Could not open $osips_fifo_file for writing: $!\n";
	print ANS $cmd_fifo;
	close (ANS);

	# Get Reply from Osips Reply Fifo
	open(FIFO, "< $fifo_reply_path") or die "Couldn't open $fifo_reply_path for reading: $!\n";
	my @fifo_line = <FIFO>;
	shift(@fifo_line);
	close (FIFO);
	unlink $fifo_reply_path;

	# Return Output
	return(@fifo_line);
}

1;

__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

OSIPsk::HandleFIFO - Perl extension for blah blah blah

=head1 SYNOPSIS

  use OSIPsk::HandleFIFO;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for OSIPsk::HandleFIFO, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

parantido, E<lt>parantido@E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2006 by root

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.8 or,
at your option, any later version of Perl 5 you may have available.

=cut
